export const SLOTS = ["Üst Giyim", "Alt Giyim", "Ayakkabı"] as const;
export type Slot = (typeof SLOTS)[number];

export const STYLES = ["Smart Casual", "Formal", "Casual"] as const;
export type Style = (typeof STYLES)[number];

export const COLORS = [
  "Beyaz",
  "Açık Mavi",
  "Lacivert",
  "Krem",
  "Bej",
  "Zeytin",
  "Antrasit",
  "Siyah",
  "Gri",
  "Kahve",
] as const;
export type Color = (typeof COLORS)[number];

export const MATERIALS = ["Pamuk", "Keten", "Yün", "Denim", "Deri"] as const;
export type Material = (typeof MATERIALS)[number];

export const BRANDS = ["Amazon", "Hepsiburada"] as const;
export type Brand = (typeof BRANDS)[number];

export const SUBCATEGORIES: Record<Slot, readonly string[]> = {
  "Üst Giyim": ["Gömlek", "Tişört", "Triko", "Kazak", "Ceket", "Gömlek Ceket"],
  "Alt Giyim": ["Pantolon", "Jean"],
  Ayakkabı: ["Sneaker", "Klasik", "Loafer"],
};

export type Analysis = {
  slot: Slot;
  subcategory: string;
  color: Color;
  style: Style;
  material: Material;
  summary: string;
  source: "vision" | "ornek" | "manuel";
};

export type Chips = {
  slot: Slot | null;
  subcategory: string | null;
  color: Color | null;
  style: Style | null;
  material: Material | null;
};

export type Product = {
  id: string;
  brand: Brand;
  name: string;
  slot: Slot;
  subcategory: string;
  color: Color;
  style: Style[];
  material: Material;
  price: number;
  image: string;
  alt: string;
};

export type Scored = { product: Product; score: number };

export type Sample = {
  id: string;
  title: string;
  note: string;
  image: string;
  analysis: Omit<Analysis, "source">;
};

export function chipsFromAnalysis(analysis: Analysis): Chips {
  return {
    slot: analysis.slot,
    subcategory: analysis.subcategory,
    color: analysis.color,
    style: analysis.style,
    material: analysis.material,
  };
}
