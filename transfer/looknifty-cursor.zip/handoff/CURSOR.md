# LookNifty — Cursor aktarımı

Bu paket prototipin kendisi değil, prototipten taşınacak kararlar ve ilk katalogdur. Sandbox’taki auth, önizleme köprüsü ve Grok eklentileri Cursor projesine kopyalanmaz.

## Ne kilitli

- Segmentler, ucuzdan pahalıya: Ekonomik, Ulaşılabilir, Lüks.
- Her sonuçta üç kategori: Üst, Alt, Ayakkabı.
- Tıklama, ürünün kendi sayfasını açar. Arama sayfası yok.
- Fotoğraf parçalara ayrılır. Her parça bir cümledir.
- Katalog ürünü de bir cümledir. Skor, aynı yer ve aynı segment içindeki cümle vektörlerinin kosinüsüdür.
- Gömlek pantolonla yarışmaz. Ekonomik, Lüks ile yarışmaz.
- Düşük skorlu kart gösterilmez. Arama adresine düşülmez.
- Kazıma yok. Sitenin iç API’si dinlenmez.
- Görsel gömme ve TF-IDF kapıdır, eşleşmenin tamamı değildir. Asıl skor gömme vektörüdür. Katalog küçükken TF-IDF aynı kapının zayıf halidir.

## İlk iş

1. `catalog.json` içindeki `live: true` dokuz kaydı veritabanına al.
2. `eko-ust-tisort-proof` için gerçek bir lacivert tişört ürün sayfası bul ve adresini yaz. Adres yoksa bu kayıt içeri girmez.
3. Sorgu cümlesi `erkek beyaz oxford gömlek, pamuk, smart casual` olsun.
4. Arama yalnız `slot = Üst` ve `segment = Ekonomik` içinde kalsın.
5. Oxford kaydı tişört kaydını yenmeli.

Bu görünmeden katalog büyütülmez. Sonra her yer ve segmentte beş ürüne çıkılır. Hafta sonu ve Galeri ondan sonra gelir. Feed ancak elle doğrulanmış katalog doğru sıralanınca bağlanır.

## Dosyalar

Cursor’a örnek ekran olarak bakılacaklar:

- `src/components/look/app.tsx` — açılış, pinler, segmentler, kategoriler
- `src/lib/fashion/segments.ts` — dokuz gerçek adres
- `src/lib/fashion/types.ts` — etiket sözleşmesi
- `src/styles.css` — renk ve yazı
- `public/looks/` — örnek kombin fotoğrafları
- `public/catalog/` — örnek ürün çekimleri, mağaza görseli değil

Cursor’da yeniden yazılacak olan skor ve katalogdur. Prototip skoru hesaplamaz. Ofis sonrası bu dokuz adrese sabit bağlıdır.

## Marka segmenti

Segment fiyattan hesaplanmaz.

- Ekonomik: LC Waikiki, FOSCO
- Ulaşılabilir: Zara, George Hogg
- Lüks: Beymen Club, Beymen Collection, Church's

Feed’den gelen marka bu listede yoksa içeri alınmaz.
