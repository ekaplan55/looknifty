import { useEffect, useMemo, useRef, useState } from "react";
import { X } from "lucide-react";
import { ProductCard } from "@/components/look/product-card";
import { analyzeLook } from "@/lib/fashion/analyze";
import { useCapsule } from "@/lib/fashion/capsule";
import { formatTry, PRODUCTS, SAMPLES } from "@/lib/fashion/catalog";
import { capsuleOutfits, emptyChips, withChip } from "@/lib/fashion/match";
import { pieceUrl, planFor, SEGMENTS, storeLabel, type Segment } from "@/lib/fashion/segments";
import {
  chipsFromAnalysis,
  COLORS,
  STYLES,
  SUBCATEGORIES,
  type Analysis,
  type Chips,
  type Sample,
} from "@/lib/fashion/types";

type Phase = "studio" | "reading" | "result" | "capsule";

const SOURCE_LABEL: Record<Analysis["source"], string> = {
  vision: "Görsel analiz",
  ornek: "Örnek kombin",
  manuel: "Elle etiket",
};

export function LookNifty() {
  const ids = useCapsule((state) => state.ids);
  const toggle = useCapsule((state) => state.toggle);
  const [hydrated, setHydrated] = useState(false);
  const [phase, setPhase] = useState<Phase>("studio");
  const [photo, setPhoto] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [chips, setChips] = useState<Chips>(emptyChips());
  const [notice, setNotice] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const finish = () => setHydrated(true);
    const unsub = useCapsule.persist.onFinishHydration(finish);
    if (useCapsule.persist.hasHydrated()) finish();
    return unsub;
  }, []);

  const saved = useMemo(
    () => ids.map((id) => PRODUCTS.find((product) => product.id === id)).filter((product) => product != null),
    [ids],
  );
  const capsuleLooks = useMemo(() => capsuleOutfits(saved), [saved]);

  function openResult(nextPhoto: string | null, next: Analysis) {
    setPhoto(nextPhoto);
    setAnalysis(next);
    setChips(chipsFromAnalysis(next));
    setNotice(null);
    setPhase("result");
    window.scrollTo({ top: 0 });
  }

  function openSample(sample: Sample) {
    openResult(sample.image, { ...sample.analysis, source: "ornek" });
  }

  async function onFile(file: File | undefined) {
    if (!file) return;
    setNotice(null);
    setPhase("reading");
    try {
      const image = await compressImage(file);
      setPhoto(image);
      const result = await analyzeLook({ data: { image } });
      if (!result.ok) {
        setNotice(result.error);
        setPhase("studio");
        return;
      }
      openResult(image, { ...result.analysis, source: "vision" });
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "Fotoğraf okunamadı");
      setPhase("studio");
    }
  }

  function startManual() {
    openResult(null, {
      slot: "Üst Giyim",
      subcategory: "Gömlek",
      color: "Beyaz",
      style: "Smart Casual",
      material: "Pamuk",
      summary: "Ekonomik, Ulaşılabilir veya Lüks. Etiket kalıbı değiştirir.",
      source: "manuel",
    });
  }

  const capsuleLabel = hydrated && ids.length > 0 ? `Kapsül ${ids.length}` : "Kapsül";

  return (
    <div className="mx-auto min-h-dvh w-full max-w-5xl px-4 pt-[max(0.75rem,env(safe-area-inset-top))] pb-16">
      <header className="sticky top-0 z-10 -mx-4 mb-8 flex items-center justify-between border-b border-line bg-ink px-4 py-3">
        <button type="button" onClick={() => setPhase("studio")} className="text-xs font-medium tracking-brand text-bone">
          LOOKNIFTY
        </button>
        <button
          type="button"
          onClick={() => setPhase(phase === "capsule" ? "studio" : "capsule")}
          className="inline-flex h-11 items-center rounded-lg border border-line px-4 text-sm text-bone"
        >
          {phase === "capsule" ? "Stüdyo" : capsuleLabel}
        </button>
      </header>

      {phase === "capsule" ? (
        <CapsuleView
          savedCount={saved.length}
          looks={capsuleLooks}
          saved={saved}
          ids={hydrated ? ids : []}
          onToggle={toggle}
          onStudio={() => setPhase("studio")}
        />
      ) : null}

      {phase === "studio" || phase === "reading" ? (
        <Studio
          reading={phase === "reading"}
          notice={notice}
          onPick={() => fileRef.current?.click()}
          onManual={startManual}
          onSample={openSample}
        />
      ) : null}

      {phase === "result" && analysis ? (
        <Result
          photo={photo}
          analysis={analysis}
          chips={chips}
          onChip={(key, value) => setChips((current) => withChip(current, key, value))}
          onAnother={() => {
            setPhase("studio");
            window.scrollTo({ top: 0 });
          }}
        />
      ) : null}

      <input
        ref={fileRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        className="sr-only"
        onChange={(event) => {
          const file = event.target.files?.[0];
          event.target.value = "";
          void onFile(file);
        }}
      />
    </div>
  );
}

function Studio({
  reading,
  notice,
  onPick,
  onManual,
  onSample,
}: {
  reading: boolean;
  notice: string | null;
  onPick: () => void;
  onManual: () => void;
  onSample: (sample: Sample) => void;
}) {
  return (
    <main className="rise flex flex-col gap-8">
      <div className="flex max-w-xl flex-col gap-3">
        <p className="text-sm text-mist">Erkek kapsül gardırop</p>
        <h1 className="text-4xl leading-tight font-medium text-bone md:text-5xl">
          Bir fotoğraf. Net bir kombin.
        </h1>
        <p className="text-base text-mist">
          Parça okunur. Ekonomik, Ulaşılabilir ve Lüks segmentlerinde kombin kurulur. Tıklama ürünün kendi sayfasını açar.
        </p>
      </div>

      <section className="flex flex-col gap-4 rounded-2xl border border-line bg-panel p-4 md:p-6">
        <div className="flex flex-col gap-1">
          <h2 className="font-sans text-lg font-medium tracking-normal">Fotoğraf yükle</h2>
          <p className="text-sm text-mist">Gömlek, ceket veya tüm kombin. JPG ya da PNG.</p>
        </div>
        <div className="flex flex-col gap-2 sm:flex-row">
          <button
            type="button"
            onClick={onPick}
            disabled={reading}
            className="inline-flex h-11 items-center justify-center rounded-lg bg-accent px-5 text-sm font-medium text-ink disabled:opacity-60"
          >
            {reading ? "Parça okunuyor" : "Fotoğraf seç"}
          </button>
          <button
            type="button"
            onClick={onManual}
            disabled={reading}
            className="inline-flex h-11 items-center justify-center rounded-lg border border-line px-5 text-sm font-medium text-bone"
          >
            Etiketle ara
          </button>
        </div>
        {reading ? <p className="text-sm text-mist">Renk, kalıp ve tarz ayrıştırılıyor.</p> : null}
        {notice ? <p className="text-sm text-bone">{notice}</p> : null}
      </section>

      <section className="flex flex-col gap-4">
        <h2 className="font-sans text-lg font-medium tracking-normal">Örneklerle dene</h2>
        <div className="grid grid-cols-3 gap-3">
          {SAMPLES.map((sample) => (
            <button
              key={sample.id}
              type="button"
              onClick={() => onSample(sample)}
              className="overflow-hidden rounded-xl border border-line bg-panel text-left"
            >
              <img src={sample.image} alt="" className="aspect-[3/4] w-full object-cover" />
              <span className="flex flex-col gap-0.5 p-3">
                <span className="text-sm font-medium text-bone">{sample.title}</span>
                <span className="text-xs text-mist">{sample.note}</span>
              </span>
            </button>
          ))}
        </div>
      </section>

      <p className="max-w-xl text-sm text-faint">
        Ofis sonrası, seçilen ürünün kendi sayfasına gider. Hafta sonu ve Galeri hâlâ örnek kombindir.
      </p>
    </main>
  );
}

function Result({
  photo,
  analysis,
  chips,
  onChip,
  onAnother,
}: {
  photo: string | null;
  analysis: Analysis;
  chips: Chips;
  onChip: <K extends keyof Chips>(key: K, value: Chips[K]) => void;
  onAnother: () => void;
}) {
  const [segment, setSegment] = useState<Segment>("Ulaşılabilir");
  const [pin, setPin] = useState(0);
  const active = [
    chips.slot ? { key: "slot" as const, label: chips.slot } : null,
    chips.subcategory ? { key: "subcategory" as const, label: chips.subcategory } : null,
    chips.color ? { key: "color" as const, label: chips.color } : null,
    chips.style ? { key: "style" as const, label: chips.style } : null,
  ].filter((chip) => chip != null);

  const slotOptions = (["Üst Giyim", "Alt Giyim", "Ayakkabı"] as const).filter((slot) => slot !== chips.slot);
  const subOptions = (chips.slot ? SUBCATEGORIES[chips.slot] : []).filter((item) => item !== chips.subcategory);
  const colorOptions = COLORS.filter((color) => color !== chips.color);
  const styleOptions = STYLES.filter((style) => style !== chips.style);
  const { name, plan } = planFor(analysis, chips);
  const rows = plan[segment];

  return (
    <main className="rise flex flex-col gap-10">
      <div className="grid items-start gap-6 md:grid-cols-[16rem_minmax(0,1fr)]">
        {photo ? (
          <div className="relative md:max-w-xs">
            <img
              src={photo}
              alt="Yüklenen kombin"
              className="aspect-[3/4] w-full rounded-2xl border border-line object-cover"
            />
            {rows[0]
              ? (["Üst", "Alt", "Ayakkabı"] as const).map((label, index) => (
                  <button
                    key={label}
                    type="button"
                    onClick={() => setPin(index)}
                    className={
                      pin === index
                        ? "absolute left-1/2 inline-flex h-11 -translate-x-1/2 items-center rounded-full bg-accent px-3 text-sm font-medium text-ink"
                        : "absolute left-1/2 inline-flex h-11 -translate-x-1/2 items-center rounded-full border border-line bg-ink/80 px-3 text-sm text-bone"
                    }
                    style={{ top: ["18%", "48%", "76%"][index] }}
                  >
                    {label}
                  </button>
                ))
              : null}
          </div>
        ) : (
          <div className="flex aspect-[3/4] w-full items-end rounded-2xl border border-line bg-panel p-4 md:max-w-xs">
            <p className="text-sm text-mist">Fotoğrafsız etiket araması</p>
          </div>
        )}
        <div className="flex flex-col gap-4">
          <p className="text-xs tracking-brand text-mist uppercase">{SOURCE_LABEL[analysis.source]}</p>
          <h1 className="text-3xl leading-tight font-medium">{analysis.summary}</h1>
          <div className="flex flex-wrap gap-2" aria-label="Aktif etiketler">
            {active.length === 0 ? (
              <p className="text-sm text-mist">Tüm etiketler kapalı. Aşağıdan bir renk veya tür seç.</p>
            ) : null}
            {active.map((chip) => (
              <button
                key={chip.key}
                type="button"
                onClick={() => onChip(chip.key, null)}
                className="inline-flex h-11 items-center gap-2 rounded-lg border border-line bg-panel-2 px-3 text-sm text-bone"
              >
                {chip.label}
                <X className="size-4 text-mist" aria-hidden />
                <span className="sr-only">etiketini kaldır</span>
              </button>
            ))}
          </div>
          <details className="rounded-xl border border-line bg-panel">
            <summary className="flex h-12 cursor-pointer list-none items-center px-4 text-sm font-medium text-bone">
              Etiketleri değiştir
            </summary>
            <div className="flex flex-col gap-4 px-4 pb-4">
              <SwapRow label="Parça" options={slotOptions} onPick={(value) => onChip("slot", value)} />
              {chips.slot ? (
                <SwapRow label="Tür" options={subOptions} onPick={(value) => onChip("subcategory", value)} />
              ) : null}
              <SwapRow label="Renk" options={colorOptions} onPick={(value) => onChip("color", value)} />
              <SwapRow label="Tarz" options={styleOptions} onPick={(value) => onChip("style", value)} />
            </div>
          </details>
          <button type="button" onClick={onAnother} className="self-start text-sm text-mist">
            Başka fotoğraf
          </button>
        </div>
      </div>

      <section className="flex flex-col gap-4">
        <div className="flex flex-col gap-1">
          <h2 className="text-2xl font-medium">{name}</h2>
          <p className="text-sm text-mist">
            {rows.some((outfit) => outfit.pieces.some((item) => item.url))
              ? "Ekonomik en alt, Ulaşılabilir orta, Lüks üst. Pin o parçayı seçer. Tıklama ürün sayfasını açar. Kart fotoğrafı örnek çekimdir."
              : "Ekonomik en alt, Ulaşılabilir orta, Lüks üst. Örnek kombinlerdir. Kart fotoğrafı markanın çekimi değildir."}
          </p>
        </div>
        <div className="grid grid-cols-3 gap-2" role="tablist" aria-label="Segment">
          {SEGMENTS.map((item) => (
            <button
              key={item}
              type="button"
              role="tab"
              aria-selected={segment === item}
              onClick={() => {
                setSegment(item);
                setPin(0);
              }}
              className={
                segment === item
                  ? "min-h-11 rounded-lg bg-accent px-2 text-center text-sm font-medium text-ink"
                  : "min-h-11 rounded-lg border border-line px-2 text-center text-sm text-bone"
              }
            >
              {item}
            </button>
          ))}
        </div>
        <div className="flex flex-col gap-6">
          {(["Üst", "Alt", "Ayakkabı"] as const).map((label, pieceIndex) => (
            <section key={label} className="flex flex-col gap-3">
              <h3 className="font-sans text-sm font-medium text-bone">{label}</h3>
              <div className="grid grid-cols-1 gap-3">
                {rows.map((outfit) => {
                  const item = outfit.pieces[pieceIndex];
                  return (
                    <a
                      key={item.id}
                      href={pieceUrl(item)}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => setPin(pieceIndex)}
                      className={
                        pin === pieceIndex
                          ? "grid grid-cols-[5.5rem_minmax(0,1fr)] gap-3 rounded-2xl border border-accent bg-panel p-3"
                          : "grid grid-cols-[5.5rem_minmax(0,1fr)] gap-3 rounded-2xl border border-line bg-panel p-3"
                      }
                    >
                      <img src={item.image} alt="" className="aspect-[3/4] w-full rounded-lg object-cover" />
                      <span className="flex min-w-0 flex-col gap-1">
                        <span className="text-xs text-mist">{item.brand}</span>
                        <span className="text-sm leading-snug font-medium text-bone">{item.name}</span>
                        <span className="text-sm text-bone tabular-nums">{formatTry(item.price)}</span>
                        <span className="text-xs text-mist">{storeLabel(item)}</span>
                      </span>
                    </a>
                  );
                })}
              </div>
            </section>
          ))}
        </div>
      </section>
    </main>
  );
}

function SwapRow<T extends string>({
  label,
  options,
  onPick,
}: {
  label: string;
  options: readonly T[];
  onPick: (value: T) => void;
}) {
  if (options.length === 0) return null;
  return (
    <div className="flex flex-col gap-2">
      <p className="text-xs text-faint">{label}</p>
      <div className="flex flex-wrap gap-2">
        {options.map((option) => (
          <button
            key={option}
            type="button"
            onClick={() => onPick(option)}
            className="inline-flex h-11 items-center rounded-lg bg-panel px-3 text-sm text-mist"
          >
            {option}
          </button>
        ))}
      </div>
    </div>
  );
}

function CapsuleView({
  savedCount,
  looks,
  saved,
  ids,
  onToggle,
  onStudio,
}: {
  savedCount: number;
  looks: ReturnType<typeof capsuleOutfits>;
  saved: (typeof PRODUCTS)[number][];
  ids: string[];
  onToggle: (id: string) => void;
  onStudio: () => void;
}) {
  return (
    <main className="rise flex flex-col gap-8">
      <div className="flex max-w-xl flex-col gap-3">
        <p className="text-sm text-mist">Kapsül</p>
        <h1 className="text-4xl leading-tight font-medium">Az parça, net kombin.</h1>
        <p className="text-base text-mist">
          Eklediğin üst, alt ve ayakkabı bu cihazda durur. Üç parça bir araya gelince kombin önerilir.
        </p>
      </div>
      {savedCount === 0 ? (
        <section className="flex flex-col gap-4 rounded-2xl border border-line bg-panel p-4">
          <p className="text-sm text-mist">Kapsül boş. Bir parçayı eşleştirip ekle.</p>
          <button
            type="button"
            onClick={onStudio}
            className="inline-flex h-11 items-center justify-center self-start rounded-lg bg-accent px-5 text-sm font-medium text-ink"
          >
            Stüdyoya dön
          </button>
        </section>
      ) : (
        <>
          {looks.length > 0 ? (
            <section className="flex flex-col gap-4">
              <h2 className="text-2xl font-medium">Bugünün kombinleri</h2>
              <div className="flex flex-col gap-3">
                {looks.map((look, index) => (
                  <article key={look.id} className="flex flex-col gap-3 rounded-2xl border border-line bg-panel p-4">
                    <p className="text-sm text-mist">Kombin {index + 1}</p>
                    <div className="grid grid-cols-3 gap-2">
                      {look.pieces.map((piece) => (
                        <img
                          key={piece.id}
                          src={piece.image}
                          alt={piece.alt}
                          className="aspect-[3/4] w-full rounded-lg object-cover"
                        />
                      ))}
                    </div>
                    <p className="text-sm text-bone">
                      {look.pieces.map((piece) => piece.name).join(" · ")}
                    </p>
                    {look.missing.length > 0 ? (
                      <p className="text-sm text-mist">{look.missing.join(" ve ")} eksik.</p>
                    ) : null}
                  </article>
                ))}
              </div>
            </section>
          ) : (
            <p className="text-sm text-mist">Kombin için en az bir üst giyim ekle.</p>
          )}
          <section className="flex flex-col gap-4">
            <h2 className="text-2xl font-medium">Parçalar</h2>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
              {saved.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  saved={ids.includes(product.id)}
                  onToggle={() => onToggle(product.id)}
                />
              ))}
            </div>
          </section>
        </>
      )}
    </main>
  );
}

async function compressImage(file: File): Promise<string> {
  const bitmap = await createImageBitmap(file).catch(() => {
    throw new Error("Bu format okunamadı. JPG veya PNG dene.");
  });
  const max = 960;
  const scale = Math.min(1, max / Math.max(bitmap.width, bitmap.height));
  const width = Math.max(1, Math.round(bitmap.width * scale));
  const height = Math.max(1, Math.round(bitmap.height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Fotoğraf işlenemedi");
  context.drawImage(bitmap, 0, 0, width, height);
  bitmap.close();
  return canvas.toDataURL("image/jpeg", 0.72);
}
