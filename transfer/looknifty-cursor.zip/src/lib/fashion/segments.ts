import type { Analysis, Chips } from "@/lib/fashion/types";

export const SEGMENTS = ["Ekonomik", "Ulaşılabilir", "Lüks"] as const;
export type Segment = (typeof SEGMENTS)[number];

type Store = "Amazon" | "Hepsiburada" | "Beymen";

export type OutfitPiece = {
  id: string;
  brand: string;
  name: string;
  price: number;
  image: string;
  store: Store;
  url?: string;
};

export type BrandOutfit = {
  id: string;
  pieces: readonly [OutfitPiece, OutfitPiece, OutfitPiece];
};

export type SegmentPlan = Record<Segment, readonly BrandOutfit[]>;

const shirt = "/catalog/shirt-white.jpg";
const navy = "/catalog/trousers-navy.jpg";
const derby = "/catalog/derby-brown.jpg";
const knit = "/catalog/sweater-cream.jpg";
const chino = "/catalog/chinos-beige.jpg";
const sneaker = "/catalog/sneakers-white.jpg";
const blazer = "/catalog/blazer-charcoal.jpg";
const black = "/catalog/jeans-black.jpg";
const loafer = "/catalog/loafers-black.jpg";

function piece(
  id: string,
  brand: string,
  name: string,
  price: number,
  image: string,
  store: Store,
  url?: string,
): OutfitPiece {
  return { id, brand, name, price, image, store, url };
}

function trio(id: string, pieces: [OutfitPiece, OutfitPiece, OutfitPiece]): BrandOutfit {
  return { id, pieces };
}

const office: SegmentPlan = {
  Ekonomik: [
    trio("ofis-u1", [
      piece(
        "ofis-u1-ust",
        "LC Waikiki",
        "Regular fit oxford",
        600,
        shirt,
        "Hepsiburada",
        "https://www.lcw.com/regular-fit-oxford-erkek-basic-gomlek-beyaz-o-4827621",
      ),
      piece(
        "ofis-u1-alt",
        "LC Waikiki",
        "Gabardin chino",
        600,
        navy,
        "Hepsiburada",
        "https://www.lcw.com/regular-fit-gabardin-erkek-chino-pantolon-lacivert-o-4352965",
      ),
      piece(
        "ofis-u1-ayak",
        "FOSCO",
        "Taba klasik",
        2600,
        derby,
        "Amazon",
        "https://www.flo.com.tr/urun/taba-hakiki-deri-erkek-klasik-ayakkabi-2807-m-201640158",
      ),
    ]),
  ],
  Ulaşılabilir: [
    trio("ofis-e1", [
      piece(
        "ofis-e1-ust",
        "Zara",
        "Cepli oxford",
        990,
        shirt,
        "Amazon",
        "https://www.zara.com/tr/tr/cepli-oxford-gomlek-p01630999.html",
      ),
      piece(
        "ofis-e1-alt",
        "Zara",
        "Takım pantolonu",
        2490,
        navy,
        "Amazon",
        "https://www.zara.com/tr/tr/regular-fit-takim-pantolonu-p01564107.html",
      ),
      piece(
        "ofis-e1-ayak",
        "George Hogg",
        "Taba oxford",
        4699,
        derby,
        "Amazon",
        "https://www.divarese.com.tr/taba-erkek-deri-ayakkabi-p-42654",
      ),
    ]),
  ],
  Lüks: [
    trio("ofis-l1", [
      piece(
        "ofis-l1-ust",
        "Beymen Club",
        "Non-iron oxford",
        4999,
        shirt,
        "Beymen",
        "https://www.beymen.com/tr/p_beymen-club-comfort-fit-beyaz-klasik-non-iron-oxford-gomlek_1769853",
      ),
      piece(
        "ofis-l1-alt",
        "Beymen Collection",
        "Yün pantolon",
        5195,
        navy,
        "Beymen",
        "https://www.beymen.com/tr/p_beymen-collection-lacivert-yun-pantolon_1906612",
      ),
      piece(
        "ofis-l1-ayak",
        "Church's",
        "Taba deri ayakkabı",
        50195,
        derby,
        "Beymen",
        "https://www.beymen.com/tr/p_churchs-taba-erkek-deri-ayakkabi_1539475",
      ),
    ]),
  ],
};

const weekend: SegmentPlan = {
  Ekonomik: [
    trio("hafta-u1", [
      piece("hafta-u1-ust", "LC Waikiki", "Krem kazak", 699, knit, "Hepsiburada"),
      piece("hafta-u1-alt", "DeFacto", "Bej chino", 999, chino, "Hepsiburada"),
      piece("hafta-u1-ayak", "Koton", "Beyaz sneaker", 899, sneaker, "Amazon"),
    ]),
    trio("hafta-u2", [
      piece("hafta-u2-ust", "Koton", "Krem kazak", 799, knit, "Hepsiburada"),
      piece("hafta-u2-alt", "Colin's", "Bej pantolon", 1090, chino, "Amazon"),
      piece("hafta-u2-ayak", "FLO", "Beyaz sneaker", 1199, sneaker, "Hepsiburada"),
    ]),
    trio("hafta-u3", [
      piece("hafta-u3-ust", "H&M", "Krem kazak", 999, knit, "Amazon"),
      piece("hafta-u3-alt", "LC Waikiki", "Bej chino", 849, chino, "Hepsiburada"),
      piece("hafta-u3-ayak", "Polaris", "Beyaz sneaker", 1299, sneaker, "Amazon"),
    ]),
  ],
  Ulaşılabilir: [
    trio("hafta-e1", [
      piece("hafta-e1-ust", "Mango", "Krem kazak", 2290, knit, "Hepsiburada"),
      piece("hafta-e1-alt", "Zara", "Bej chino", 2190, chino, "Amazon"),
      piece("hafta-e1-ayak", "Network", "Beyaz sneaker", 2490, sneaker, "Hepsiburada"),
    ]),
    trio("hafta-e2", [
      piece("hafta-e2-ust", "Massimo Dutti", "Krem kazak", 3490, knit, "Amazon"),
      piece("hafta-e2-alt", "Tween", "Bej pantolon", 1890, chino, "Hepsiburada"),
      piece("hafta-e2-ayak", "Divarese", "Beyaz sneaker", 3290, sneaker, "Amazon"),
    ]),
    trio("hafta-e3", [
      piece("hafta-e3-ust", "Zara", "Krem kazak", 1990, knit, "Amazon"),
      piece("hafta-e3-alt", "Mango", "Bej chino", 2390, chino, "Hepsiburada"),
      piece("hafta-e3-ayak", "Hotiç", "Beyaz sneaker", 2790, sneaker, "Hepsiburada"),
    ]),
  ],
  Lüks: [
    trio("hafta-l1", [
      piece("hafta-l1-ust", "Hugo Boss", "Krem kazak", 7490, knit, "Beymen"),
      piece("hafta-l1-alt", "Boggi Milano", "Bej pantolon", 9900, chino, "Beymen"),
      piece("hafta-l1-ayak", "Common Projects", "Beyaz sneaker", 14900, sneaker, "Beymen"),
    ]),
    trio("hafta-l2", [
      piece("hafta-l2-ust", "Vakko", "Krem kazak", 8900, knit, "Beymen"),
      piece("hafta-l2-alt", "Hackett", "Bej pantolon", 11200, chino, "Beymen"),
      piece("hafta-l2-ayak", "Axel Arigato", "Beyaz sneaker", 12900, sneaker, "Beymen"),
    ]),
    trio("hafta-l3", [
      piece("hafta-l3-ust", "Lufian", "Krem kazak", 4290, knit, "Beymen"),
      piece("hafta-l3-alt", "Hugo Boss", "Bej pantolon", 8900, chino, "Beymen"),
      piece("hafta-l3-ayak", "Koio", "Beyaz sneaker", 11900, sneaker, "Beymen"),
    ]),
  ],
};

const gallery: SegmentPlan = {
  Ekonomik: [
    trio("galeri-u1", [
      piece("galeri-u1-ust", "LC Waikiki", "Antrasit blazer", 1499, blazer, "Hepsiburada"),
      piece("galeri-u1-alt", "DeFacto", "Siyah pantolon", 899, black, "Hepsiburada"),
      piece("galeri-u1-ayak", "FLO", "Siyah loafer", 1299, loafer, "Amazon"),
    ]),
    trio("galeri-u2", [
      piece("galeri-u2-ust", "Koton", "Antrasit ceket", 1799, blazer, "Hepsiburada"),
      piece("galeri-u2-alt", "Colin's", "Siyah pantolon", 999, black, "Amazon"),
      piece("galeri-u2-ayak", "Polaris", "Siyah loafer", 1199, loafer, "Hepsiburada"),
    ]),
    trio("galeri-u3", [
      piece("galeri-u3-ust", "H&M", "Antrasit blazer", 1990, blazer, "Amazon"),
      piece("galeri-u3-alt", "LC Waikiki", "Siyah pantolon", 799, black, "Hepsiburada"),
      piece("galeri-u3-ayak", "DeFacto", "Siyah loafer", 1399, loafer, "Hepsiburada"),
    ]),
  ],
  Ulaşılabilir: [
    trio("galeri-e1", [
      piece("galeri-e1-ust", "Zara", "Antrasit blazer", 3990, blazer, "Amazon"),
      piece("galeri-e1-alt", "Mango", "Siyah pantolon", 2290, black, "Hepsiburada"),
      piece("galeri-e1-ayak", "Hotiç", "Siyah deri loafer", 3490, loafer, "Hepsiburada"),
    ]),
    trio("galeri-e2", [
      piece("galeri-e2-ust", "Massimo Dutti", "Antrasit blazer", 5490, blazer, "Amazon"),
      piece("galeri-e2-alt", "Network", "Siyah pantolon", 2490, black, "Hepsiburada"),
      piece("galeri-e2-ayak", "Divarese", "Siyah deri loafer", 4290, loafer, "Amazon"),
    ]),
    trio("galeri-e3", [
      piece("galeri-e3-ust", "Tween", "Antrasit ceket", 3290, blazer, "Hepsiburada"),
      piece("galeri-e3-alt", "Zara", "Siyah pantolon", 2190, black, "Amazon"),
      piece("galeri-e3-ayak", "Hotiç", "Siyah loafer", 3290, loafer, "Hepsiburada"),
    ]),
  ],
  Lüks: [
    trio("galeri-l1", [
      piece("galeri-l1-ust", "Hugo Boss", "Antrasit blazer", 14900, blazer, "Beymen"),
      piece("galeri-l1-alt", "Boggi Milano", "Siyah yün pantolon", 9900, black, "Beymen"),
      piece("galeri-l1-ayak", "Magnanni", "Siyah loafer", 21900, loafer, "Beymen"),
    ]),
    trio("galeri-l2", [
      piece("galeri-l2-ust", "Vakko", "Antrasit blazer", 18900, blazer, "Beymen"),
      piece("galeri-l2-alt", "Hackett", "Siyah pantolon", 11200, black, "Beymen"),
      piece("galeri-l2-ayak", "Santoni", "Siyah loafer", 28900, loafer, "Beymen"),
    ]),
    trio("galeri-l3", [
      piece("galeri-l3-ust", "Lufian", "Antrasit ceket", 7990, blazer, "Beymen"),
      piece("galeri-l3-alt", "Hugo Boss", "Siyah pantolon", 8900, black, "Beymen"),
      piece("galeri-l3-ayak", "Berwick", "Siyah loafer", 16900, loafer, "Beymen"),
    ]),
  ],
};

export function planFor(analysis: Analysis, chips: Chips): { name: string; plan: SegmentPlan } {
  const subcategory = chips.subcategory ?? analysis.subcategory;
  const color = chips.color ?? analysis.color;
  if (subcategory === "Ceket" || color === "Antrasit") {
    return { name: "Galeri", plan: gallery };
  }
  if (subcategory === "Kazak" || color === "Krem") {
    return { name: "Hafta sonu", plan: weekend };
  }
  return { name: "Ofis sonrası", plan: office };
}

export function pieceUrl(item: OutfitPiece): string {
  if (item.url) return item.url;
  const q = encodeURIComponent(`${item.brand} ${item.name}`);
  switch (item.store) {
    case "Amazon":
      return `https://www.amazon.com.tr/s?k=${q}`;
    case "Hepsiburada":
      return `https://www.hepsiburada.com/ara?q=${q}`;
    case "Beymen":
      return `https://www.beymen.com/search?q=${q}`;
  }
}

export function storeLabel(item: OutfitPiece): string {
  if (item.url) return "Ürünü aç";
  if (item.store === "Amazon") return "Amazon'da ara";
  if (item.store === "Hepsiburada") return "Hepsiburada'da ara";
  return "Beymen'de ara";
}
