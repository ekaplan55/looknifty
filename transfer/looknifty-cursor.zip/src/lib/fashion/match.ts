import type { Chips, Color, Product, Scored, Slot, Style } from "@/lib/fashion/types";

/** Renk uyumu: aynı ton değil, kapsülde yan yana duran tamamlayıcılar. */
const COMPLEMENT: Record<Color, Color[]> = {
  Beyaz: ["Lacivert", "Antrasit", "Siyah", "Bej", "Kahve", "Gri"],
  "Açık Mavi": ["Bej", "Lacivert", "Beyaz", "Kahve", "Gri"],
  Lacivert: ["Beyaz", "Bej", "Krem", "Kahve", "Gri"],
  Krem: ["Lacivert", "Bej", "Kahve", "Antrasit"],
  Bej: ["Lacivert", "Beyaz", "Kahve", "Zeytin", "Krem"],
  Zeytin: ["Bej", "Krem", "Kahve", "Beyaz"],
  Antrasit: ["Beyaz", "Siyah", "Gri", "Krem"],
  Siyah: ["Beyaz", "Gri", "Bej", "Krem"],
  Gri: ["Beyaz", "Lacivert", "Siyah", "Antrasit"],
  Kahve: ["Bej", "Krem", "Lacivert", "Beyaz"],
};

function unit(tokens: string[]): Map<string, number> {
  const raw = new Map<string, number>();
  for (const token of tokens) {
    const key = token.trim().toLowerCase();
    if (!key) continue;
    raw.set(key, (raw.get(key) ?? 0) + 1);
  }
  let norm = 0;
  for (const value of raw.values()) norm += value * value;
  norm = Math.sqrt(norm) || 1;
  const vec = new Map<string, number>();
  for (const [key, value] of raw) vec.set(key, value / norm);
  return vec;
}

function cosine(a: Map<string, number>, b: Map<string, number>): number {
  let score = 0;
  for (const [key, value] of a) {
    const other = b.get(key);
    if (other) score += value * other;
  }
  return score;
}

function clamp01(n: number): number {
  return Math.max(0, Math.min(1, n));
}

function productTokens(product: Product): string[] {
  return [product.slot, product.subcategory, product.color, product.material, ...product.style];
}

function chipTokens(chips: Chips): string[] {
  return [chips.slot, chips.subcategory, chips.color, chips.style, chips.material].filter(
    (token): token is string => Boolean(token),
  );
}

/** Hibrit skor: öznitelik vektörünün kosinüsü + yapısal eşleşme. */
export function nearest(products: Product[], chips: Chips, limit = 4): Scored[] {
  if (chipTokens(chips).length === 0) return [];
  return products
    .map((product) => ({ product, score: nearScore(product, chips) }))
    .filter((row) => row.score > 0.05)
    .sort((a, b) => b.score - a.score || a.product.price - b.product.price)
    .slice(0, limit);
}

function nearScore(product: Product, chips: Chips): number {
  const score =
    cosine(unit(chipTokens(chips)), unit(productTokens(product))) * 0.62 +
    slotBonus(product.slot, chips.slot) +
    (chips.subcategory && product.subcategory === chips.subcategory ? 0.1 : 0) +
    (chips.color && product.color === chips.color ? 0.12 : 0) +
    (chips.style && product.style.includes(chips.style) ? 0.08 : 0) +
    (chips.material && product.material === chips.material ? 0.04 : 0);
  return clamp01(score);
}

function slotBonus(productSlot: Slot, querySlot: Slot | null): number {
  if (!querySlot) return 0.04;
  return productSlot === querySlot ? 0.2 : -0.28;
}

export function complete(products: Product[], chips: Chips): { slot: Slot; items: Scored[] }[] {
  const targets = (["Üst Giyim", "Alt Giyim", "Ayakkabı"] as const).filter(
    (slot) => slot !== chips.slot,
  );
  const slots = chips.slot ? targets : (["Alt Giyim", "Ayakkabı"] as const);
  return slots.map((slot) => ({
    slot,
    items: products
      .filter((product) => product.slot === slot)
      .map((product) => ({ product, score: completeScore(product, chips) }))
      .sort((a, b) => b.score - a.score || a.product.price - b.product.price)
      .slice(0, 3),
  }));
}

function completeScore(product: Product, chips: Chips): number {
  const query = unit([chips.style, chips.material, chips.subcategory].filter((t): t is string => Boolean(t)));
  const doc = unit([product.material, product.subcategory, ...product.style]);
  let score = cosine(query, doc) * 0.4;
  if (chips.style && product.style.includes(chips.style)) score += 0.28;
  if (chips.color) {
    const mates = COMPLEMENT[chips.color];
    if (mates.includes(product.color)) score += 0.34;
    else if (product.color === chips.color) score += 0.08;
  } else {
    score += 0.12;
  }
  return clamp01(score);
}

export type Outfit = {
  id: string;
  pieces: Product[];
  missing: Slot[];
  score: number;
};

export function capsuleOutfits(saved: Product[]): Outfit[] {
  const uppers = saved.filter((product) => product.slot === "Üst Giyim");
  if (uppers.length === 0) return [];
  const outfits = uppers.map((upper) => {
    const chips: Chips = {
      slot: upper.slot,
      subcategory: upper.subcategory,
      color: upper.color,
      style: upper.style[0] ?? null,
      material: upper.material,
    };
    const lower = bestIn(saved, "Alt Giyim", chips);
    const shoe = bestIn(saved, "Ayakkabı", chips);
    const pieces = [upper, lower, shoe].filter((piece): piece is Product => Boolean(piece));
    const missing = (["Alt Giyim", "Ayakkabı"] as const).filter((slot) => !pieces.some((p) => p.slot === slot));
    const score =
      (lower ? completeScore(lower, chips) : 0) * 0.5 + (shoe ? completeScore(shoe, chips) : 0) * 0.5;
    return { id: pieces.map((piece) => piece.id).join("-"), pieces, missing: [...missing], score };
  });
  const seen = new Set<string>();
  return outfits
    .sort((a, b) => b.pieces.length - a.pieces.length || b.score - a.score)
    .filter((outfit) => {
      if (seen.has(outfit.id)) return false;
      seen.add(outfit.id);
      return true;
    })
    .slice(0, 3);
}

function bestIn(saved: Product[], slot: Slot, chips: Chips): Product | null {
  const pool = saved.filter((product) => product.slot === slot);
  if (pool.length === 0) return null;
  return pool
    .map((product) => ({ product, score: completeScore(product, chips) }))
    .sort((a, b) => b.score - a.score)[0]!.product;
}

export function percent(score: number): number {
  return Math.round(clamp01(score) * 100);
}

export function emptyChips(): Chips {
  return { slot: null, subcategory: null, color: null, style: null, material: null };
}

export function withChip<K extends keyof Chips>(chips: Chips, key: K, value: Chips[K]): Chips {
  const next = { ...chips, [key]: value };
  if (key === "slot") {
    next.subcategory = null;
  }
  if (key === "style") {
    next.style = value as Style | null;
  }
  return next;
}
