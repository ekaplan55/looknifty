import { formatTry, storeUrl } from "@/lib/fashion/catalog";
import { percent } from "@/lib/fashion/match";
import type { Product } from "@/lib/fashion/types";

type Props = {
  product: Product;
  score?: number;
  saved: boolean;
  onToggle: () => void;
};

export function ProductCard({ product, score, saved, onToggle }: Props) {
  return (
    <article className="flex flex-col overflow-hidden rounded-2xl border border-line bg-panel">
      <img src={product.image} alt={product.alt} className="aspect-[3/4] w-full object-cover" />
      <div className="flex flex-1 flex-col gap-3 p-4">
        <div className="flex flex-col gap-1">
          <p className="text-xs text-mist">{product.brand}</p>
          <h3 className="font-sans text-base leading-snug font-medium tracking-normal text-bone">
            {product.name}
          </h3>
          <p className="text-sm text-mist">
            {product.color}
            <span className="text-faint"> · </span>
            {product.subcategory}
          </p>
        </div>
        <div className="mt-auto flex items-baseline justify-between gap-2">
          <p className="text-sm font-medium text-bone tabular-nums">{formatTry(product.price)}</p>
          {typeof score === "number" ? (
            <p className="text-xs text-faint tabular-nums">uyum {percent(score)}</p>
          ) : null}
        </div>
        <div className="flex flex-col gap-2">
          <a
            href={storeUrl(product)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex h-11 items-center justify-center rounded-lg bg-accent px-3 text-sm font-medium text-ink"
          >
            {product.brand === "Amazon" ? "Amazon'da ara" : "Hepsiburada'da ara"}
          </a>
          <button
            type="button"
            onClick={onToggle}
            className="inline-flex h-11 items-center justify-center rounded-lg border border-line text-sm font-medium text-bone"
            aria-pressed={saved}
          >
            {saved ? "Kapsülden çıkar" : "Kapsüle ekle"}
          </button>
        </div>
      </div>
    </article>
  );
}
