import { createServerFn } from "@tanstack/react-start";
import {
  COLORS,
  MATERIALS,
  SLOTS,
  STYLES,
  SUBCATEGORIES,
  type Analysis,
  type Color,
  type Material,
  type Slot,
  type Style,
} from "@/lib/fashion/types";

const MAX_IMAGE = 1_600_000;

const PROMPT = `Sen erkek giyim görsel analistisin. Fotoğraftaki en belirgin tek parçayı (öncelik üst giyim) kapalı listedeki değerlerle sınıflandır.
Yalnızca JSON döndür, markdown yok.
{"slot":"Üst Giyim|Alt Giyim|Ayakkabı","subcategory":"...","color":"...","style":"Smart Casual|Formal|Casual","material":"Pamuk|Keten|Yün|Denim|Deri","summary":"Türkçe tek cümle, en fazla 18 kelime"}
subcategory yalnızca şunlar: Gömlek, Tişört, Triko, Kazak, Ceket, Gömlek Ceket, Pantolon, Jean, Sneaker, Klasik, Loafer.
color yalnızca şunlar: Beyaz, Açık Mavi, Lacivert, Krem, Bej, Zeytin, Antrasit, Siyah, Gri, Kahve.`;

type Raw = {
  slot?: string;
  subcategory?: string;
  color?: string;
  style?: string;
  material?: string;
  summary?: string;
};

export type AnalyzeResponse =
  | { ok: true; analysis: Omit<Analysis, "source"> }
  | { ok: false; error: string };

export const analyzeLook = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    if (!input || typeof input !== "object") throw new Error("Geçersiz istek");
    const image = (input as { image?: unknown }).image;
    if (typeof image !== "string" || !image.startsWith("data:image/")) {
      throw new Error("Fotoğraf okunamadı");
    }
    if (image.length > MAX_IMAGE) throw new Error("Fotoğraf çok büyük. Daha yakından kırpıp tekrar dene.");
    const mime = image.slice(5, image.indexOf(";"));
    if (mime !== "image/jpeg" && mime !== "image/png") {
      throw new Error("Yalnızca JPG veya PNG kullanılabilir");
    }
    return { image };
  })
  .handler(async ({ data }): Promise<AnalyzeResponse> => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false, error: "Görsel analiz bu ortamda kapalı. Etiketle arayabilirsin." };

    try {
      const text = await callVision(apiKey, data.image);
      const analysis = normalize(text);
      if (!analysis) return { ok: false, error: "Parça okunamadı. Etiketleri elle seç." };
      return { ok: true, analysis };
    } catch (error) {
      console.error("[looknifty] vision failed", error instanceof Error ? error.message : "error");
      return { ok: false, error: "Görsel analiz yanıt vermedi. Etiketle aramaya devam edebilirsin." };
    }
  });

async function callVision(apiKey: string, image: string): Promise<string> {
  const headers = {
    "Content-Type": "application/json",
    Authorization: `Bearer ${apiKey}`,
  };
  const first = await fetch("https://api.x.ai/v1/responses", {
    method: "POST",
    headers,
    signal: AbortSignal.timeout(25_000),
    body: JSON.stringify({
      model: "grok-4.5",
      max_output_tokens: 400,
      reasoning: { effort: "low" },
      input: [
        {
          role: "user",
          content: [
            { type: "input_image", image_url: image, detail: "low" },
            { type: "input_text", text: PROMPT },
          ],
        },
      ],
    }),
  });
  if (first.ok) return extractText(await first.json());

  const second = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers,
    signal: AbortSignal.timeout(25_000),
    body: JSON.stringify({
      model: "grok-4.5",
      max_tokens: 400,
      reasoning_effort: "low",
      messages: [
        {
          role: "user",
          content: [
            { type: "image_url", image_url: { url: image, detail: "low" } },
            { type: "text", text: PROMPT },
          ],
        },
      ],
    }),
  });
  if (!second.ok) throw new Error(`vision ${first.status}/${second.status}`);
  return extractText(await second.json());
}

function extractText(body: unknown): string {
  if (!body || typeof body !== "object") return "";
  const record = body as Record<string, unknown>;
  if (typeof record.output_text === "string") return record.output_text;
  const choices = record.choices;
  if (Array.isArray(choices)) {
    const message = (choices[0] as { message?: { content?: unknown } } | undefined)?.message?.content;
    if (typeof message === "string") return message;
  }
  const chunks: string[] = [];
  const output = record.output;
  if (!Array.isArray(output)) return "";
  for (const item of output) {
    if (!item || typeof item !== "object") continue;
    const content = (item as { content?: unknown }).content;
    if (!Array.isArray(content)) continue;
    for (const part of content) {
      if (part && typeof part === "object" && typeof (part as { text?: unknown }).text === "string") {
        chunks.push((part as { text: string }).text);
      }
    }
  }
  return chunks.join("\n");
}

function normalize(text: string): Omit<Analysis, "source"> | null {
  const match = text.match(/\{[\s\S]*\}/);
  if (!match) return null;
  let raw: Raw;
  try {
    raw = JSON.parse(match[0]) as Raw;
  } catch {
    return null;
  }
  const slot = pickSlot(raw.slot ?? "");
  if (!slot) return null;
  const subcategory = pickSub(slot, raw.subcategory ?? "") ?? SUBCATEGORIES[slot][0]!;
  const color = pickColor(raw.color ?? "") ?? "Beyaz";
  const style = pickStyle(raw.style ?? "") ?? "Smart Casual";
  const material = pickMaterial(raw.material ?? "") ?? "Pamuk";
  const summary = (raw.summary ?? "").replace(/\s+/g, " ").trim().slice(0, 180);
  return {
    slot,
    subcategory,
    color,
    style,
    material,
    summary: summary || `${color} ${subcategory.toLowerCase()}, ${style.toLowerCase()} bir parça.`,
  };
}

function fold(value: string): string {
  return value
    .toLocaleLowerCase("tr")
    .normalize("NFD")
    .replace(/\p{M}/gu, "");
}

function pickSlot(value: string): Slot | null {
  const text = fold(value);
  if (text.includes("ayakk")) return "Ayakkabı";
  if (text.includes("alt") || text.includes("pant") || text.includes("jean")) return "Alt Giyim";
  if (text.includes("ust") || text.includes("gomlek") || text.includes("ceket") || text.includes("triko")) {
    return "Üst Giyim";
  }
  return SLOTS.find((slot) => fold(slot) === text) ?? null;
}

function pickSub(slot: Slot, value: string): string | null {
  const text = fold(value);
  const options = SUBCATEGORIES[slot];
  const alias: Record<string, string> = {
    shirt: "Gömlek",
    oxford: "Gömlek",
    gomlek: "Gömlek",
    tshirt: "Tişört",
    tisort: "Tişört",
    polo: "Triko",
    triko: "Triko",
    kazak: "Kazak",
    sweater: "Kazak",
    blazer: "Ceket",
    ceket: "Ceket",
    overshirt: "Gömlek Ceket",
    pantolon: "Pantolon",
    chino: "Pantolon",
    jean: "Jean",
    sneaker: "Sneaker",
    derby: "Klasik",
    klasik: "Klasik",
    loafer: "Loafer",
  };
  for (const [key, label] of Object.entries(alias)) {
    if (text.includes(key) && options.includes(label)) return label;
  }
  return options.find((option) => fold(option) === text || text.includes(fold(option))) ?? null;
}

function pickColor(value: string): Color | null {
  const text = fold(value);
  const pairs: [string, Color][] = [
    ["acik mavi", "Açık Mavi"],
    ["light blue", "Açık Mavi"],
    ["lacivert", "Lacivert"],
    ["navy", "Lacivert"],
    ["antrasit", "Antrasit"],
    ["kahvereng", "Kahve"],
    ["zeytin", "Zeytin"],
    ["haki", "Zeytin"],
    ["olive", "Zeytin"],
    ["beyaz", "Beyaz"],
    ["white", "Beyaz"],
    ["mavi", "Açık Mavi"],
    ["krem", "Krem"],
    ["ekru", "Krem"],
    ["cream", "Krem"],
    ["bej", "Bej"],
    ["camel", "Bej"],
    ["siyah", "Siyah"],
    ["black", "Siyah"],
    ["gri", "Gri"],
    ["grey", "Gri"],
    ["gray", "Gri"],
    ["kahve", "Kahve"],
    ["taba", "Kahve"],
    ["brown", "Kahve"],
  ];
  for (const [key, color] of pairs) {
    if (text.includes(key)) return color;
  }
  return COLORS.find((color) => fold(color) === text) ?? null;
}

function pickStyle(value: string): Style | null {
  const text = fold(value);
  if (text.includes("formal") || text.includes("ofis") || text.includes("klasik")) return "Formal";
  if (text.includes("casual") && !text.includes("smart")) return "Casual";
  if (text.includes("smart") || text.includes("gunluk")) return "Smart Casual";
  return STYLES.find((style) => fold(style) === text) ?? null;
}

function pickMaterial(value: string): Material | null {
  const text = fold(value);
  if (text.includes("keten") || text.includes("linen")) return "Keten";
  if (text.includes("yun") || text.includes("wool") || text.includes("merino")) return "Yün";
  if (text.includes("denim") || text.includes("jean")) return "Denim";
  if (text.includes("deri") || text.includes("leather") || text.includes("suet")) return "Deri";
  if (text.includes("pamuk") || text.includes("cotton")) return "Pamuk";
  return MATERIALS.find((material) => fold(material) === text) ?? null;
}
