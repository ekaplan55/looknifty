import { createFileRoute } from "@tanstack/react-router";
import { LookNifty } from "@/components/look/app";

export const Route = createFileRoute("/")({
  component: LookNifty,
});
