import { create } from "zustand";
import { persist } from "zustand/middleware";

type CapsuleState = {
  ids: string[];
  toggle: (id: string) => void;
};

export const useCapsule = create<CapsuleState>()(
  persist(
    (set, get) => ({
      ids: [],
      toggle: (id) => {
        const ids = get().ids;
        set({ ids: ids.includes(id) ? ids.filter((item) => item !== id) : [id, ...ids] });
      },
    }),
    { name: "looknifty-capsule" },
  ),
);
